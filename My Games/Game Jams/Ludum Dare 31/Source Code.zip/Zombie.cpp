#include "Engine.h"
#include "Zombie.h"

Zombie::Zombie()
{
    this->animationValue = 0;
    this->health = 0;
    this->attackDamage = 0;
    this->worthMoney = 0;
    this->worthExperience = 0;
}

void Zombie::setStats(int health, int attackDamage, int worthMoney, int worthExperience){
    this->health = health;
    this->maxHealth = health;
    this->attackDamage = attackDamage;
    this->worthMoney = worthMoney;
    this->worthExperience = worthExperience;
}

void Zombie::takeDamage(int damage){
    this->health -= damage;
    if(this->health <= 0){
        this->active = false; //Death animation maybe?
        playerList[0]->addMoney(this->worthMoney);
        playerList[0]->addExperience(this->worthExperience);
    }
}

int Zombie::getHealth(int id){
    if(id == 0){
        return this->health;
    }else if(id == 1){
        return this->maxHealth;
    }
    return 0;
}

void Zombie::update(){
    this->colX = false, this->colY = false;

    if(!this->untilFinished){
        this->setAnimationValue(1, false, 1);
    }

    this->angle = -atan2(this->centerX - playerList[0]->centerX, this->centerY - playerList[0]->centerY);

    this->deltaX = sin(this->angle) * this->movementSpeed;
    this->deltaY = -cos(this->angle) * this->movementSpeed;

    float loopI = ceil(this->movementSpeed/this->width);

    for(float i = 0; i < loopI && (!this->colX || !this->colY); i++){

        if(checkCollision(this->posX + this->deltaX/loopI, this->posY, playerList[0]->posX, playerList[0]->posY,
            this->width, this->height, playerList[0]->width, playerList[0]->height)){
            this->colX = true;

            this->setAnimationValue(3, true, 2);
            //printf("\nHit Player");
        }
        if(checkCollision(this->posX, this->posY + this->deltaY/loopI, playerList[0]->posX, playerList[0]->posY,
            this->width, this->height, playerList[0]->width, playerList[0]->height)){
            this->colY = true;

            this->setAnimationValue(3, true, 2);
            //printf("\nHit Player");
        }

        for(int lI = 0; lI < MAX_LIVING && (!this->colX || !this->colY); lI++){
            if(livingList[lI] != NULL && livingList[lI]->checkActive() && livingList[lI]->entityId != this->entityId){
                if(checkCollision(this->posX + this->deltaX/loopI, this->posY, livingList[lI]->posX, livingList[lI]->posY,
                    this->width, this->height, livingList[lI]->width, livingList[lI]->height)){
                    this->colX = true;
                }
                if(checkCollision(this->posX, this->posY + this->deltaY/loopI, livingList[lI]->posX, livingList[lI]->posY,
                    this->width, this->height, livingList[lI]->width, livingList[lI]->height)){
                    this->colY = true;
                }
            }
        }

        if(!isPassable(this->posX + this->deltaX/loopI, this->posY, this->width, this->height) && !this->colX){
            this->colX = true;
        }else if(!this->colX){
            this->posX += this->deltaX/loopI;
        }

        if(!isPassable(this->posX, this->posY + this->deltaY/loopI , this->width, this->height) && !this->colY){
            this->colY = true;
        }else if(!this->colY){
            this->posY += this->deltaY/loopI;
        }
    }

    if(this->rememberAnimationValue == 3 && this->untilFinished){
        if(this->nextFrame && this->frameX == 2){
            this->deltaX = sin(this->angle)*8;
            this->deltaY = -cos(this->angle)*8;

            if(checkCollision(this->posX + this->deltaX, this->posY + this->deltaY, playerList[0]->posX, playerList[0]->posY,
                this->width, this->height, playerList[0]->width, playerList[0]->height)){

                playerList[0]->takeDamage(this->attackDamage);
            }
        }
    }

    this->updateCenter();

    this->updateAnimation();

    this->deltaX = 0;
    this->deltaY = 0;
}

void Zombie::draw(){
    al_draw_rotated_bitmap(this->frameImage, this->width/2, this->height/2, this->posX+this->width/2, this->posY+this->height/2, this->angle, NULL);

    al_draw_rectangle(this->posX-1, this->posY-11, this->posX+this->width+1, this->posY-4, al_map_rgb(200,200,200), 2);
    al_draw_filled_rectangle(this->posX, this->posY-10, 2+(this->posX-2)+this->width/this->maxHealth*this->health, this->posY-5, al_map_rgb(200,0,0));
}

#include "Engine.h"
#include "MenuState.h"
#include "GameState.h"
#include "PlayState.h"

//Initalization +
struct TILE_TYPE{
	bool isPassable;
};

bool isPassable(float x, float y, float width, float height, float deltaX, float deltaY);
bool checkCollision(float x, float y, float ex, float ey, float width, float height, float ewidth, float eheight);
bool insideMap(float x, float y, float width, float height);
void addButtonToList(Button *newButton);
void addMissileToList(MissileEntity *newMissile);
void addLivingToList(LivingEntity *newLiving);
void addDebugToList(DebugClass *newDebug);
void loadMapArray();
void saveMapArray();
void drawMap();
void drawTile(float x, float y, int tileId);

ALLEGRO_DISPLAY *display;

ALLEGRO_FONT *defaultFont;
ALLEGRO_FONT *smallFont;
ALLEGRO_FONT *bigFont;
ALLEGRO_BITMAP *cursorImage;
ALLEGRO_BITMAP *playerImage;
ALLEGRO_BITMAP *bulletImage;
ALLEGRO_BITMAP *pixelImage;
ALLEGRO_BITMAP *zombieImage;
ALLEGRO_BITMAP *explosionImage;

ALLEGRO_BITMAP *portalImage;

ALLEGRO_KEYBOARD_STATE keyState;
ALLEGRO_MOUSE_STATE mouseState;
ALLEGRO_EVENT_QUEUE *event_queue;
ALLEGRO_TIMER *timer;

Button *buttonList[MAX_BUTTONS];
MissileEntity *missileList[MAX_MISSILES];
LivingEntity *livingList[MAX_LIVING];
DebugClass *debugList[MAX_DEBUG];
Player *playerList[1];

Engine engine;

int mapArray[mapArrayWidth][mapArrayHeight];

///gunId;fireTime;attackDamage;maxMagazine;reloadTime;bulletSpeed;autoFire;cost;
int weaponArray[5][3][8] =  {{{0, 20, 1, 10, 60, 16, 0, 10}, {0, 10, 2, 6, 120, 16, 0, 15}, {0, 30, 2, 20, 180, 16, 0, 30}},
                            {{0, 60, 5, 3, 120, 32, 0, 45}, {2, 20, 2, 25, 90, 16, 1, 60}, {3, 90, 2, 2, 60, 16, 0, 60}},
                            {{0, 30, 5, 8, 60, 24, 0, 80}, {2, 15, 3, 20, 60, 16, 1, 115}, {1, 60, 3, 3, 75, 16, 0, 130}},
                            {{2, 5, 1, 50, 120, 24, 1, 200}, {1, 15, 2, 12, 45, 16, 1, 300}, {4, 60, 5, 3, 120, 8, 0, 400}},
                            {{5, 1, 3, 999, 180, 16, 1, 1000}, {4, 1, 2, 200, 120, 6, 1, 1500}, {6, 1, 10, 1, 60, 0, 0, 2000}}};

///maxHealth;meleeDamage;maxStamina;maxMovementSpeed;
float skillArray[5][3][4] = {{{1.5, 1, 1, 1}, {1, 2, 1, 1}, {1, 1, 1.5, 1}},
                            {{2, 1, 1, 1}, {1, 2, 1, 1}, {1, 1, 1, 1.5}},
                            {{2, 1, 1, 1}, {1, 1.5, 1, 1}, {1, 1, 1.5, 1.5}},
                            {{1.5, 1.5, 1.5, 1.5}, {2, 1, 2, 1}, {1, 1, 2, 2}},
                            {{2, 2, 2, 2}, {3, 1, 3, 1}, {1, 1, 4, 4}}};

bool boughtWeapon, leveledSkill;
int tierWeapon, tierSkill;

float fpsTimeNew, fpsCounter, fpsTimeOld;

bool drawScreen, timerEvent, done, mouseButtonLeft, mouseButtonLeftClick, mouseButtonRight, mouseButtonRightClick, inGame;
float mouseX, mouseY;
int lastKeyPress, mouseWheel = 0;

int enemySpawnRateHelper, enemySpawnRate, pauseBetweenWavesHelper, amountEnemiesSpawned, amountEnemiesSpawn, enemySpeed, enemyMoney, enemyExperience, enemyDamage, enemyHealth;
bool pauseBetweenWavesActive, enemySpawnAll, winStatement, loseStatement, paused;
int wave;

TILE_TYPE tileIndex[] = {
	{true}, // (0) TILE_EMPTY
	{false}, // (1) TILE_WALL
	{true}, // (1) TILE_PORTAL
};
//Initalization -

int main(){
    srand(time(0));

	Engine engine;

	//Initialize the Engine
	engine.init("Ludum Dare 31 - Whole Game on One Screen", screenWidth, screenHeight, false);

	//Load the Menu
	engine.changeState(PlayState::instance());

    //Timestep Variables
    double t = 0.0;
    double dt = 1/60.0;

    double currentTime = 0.0;
    double newTime = 0.0;
    double frameTime = 0.0;

    double accumulator = 0.0;

	//Main Loop
    while(engine.running()){
        ALLEGRO_EVENT events;
        al_wait_for_event(event_queue, &events);

        timerEvent = false;

        if(events.type == ALLEGRO_EVENT_DISPLAY_CLOSE){
            engine.quit();
        }

        if(events.type == ALLEGRO_EVENT_TIMER){
            timerEvent = true;
        }
        //Main Timer Event +
        if(timerEvent){
            al_get_mouse_state(&mouseState);

            al_get_keyboard_state(&keyState);

            //Update Mouse Variables +
            mouseX = al_get_mouse_state_axis(&mouseState,0);
            mouseY = al_get_mouse_state_axis(&mouseState,1);
            mouseWheel = al_get_mouse_state_axis(&mouseState, 2);

            if(al_mouse_button_down(&mouseState, 1)){
                mouseButtonLeft = true;
            }else if(mouseButtonLeft){
                mouseButtonLeftClick = true;
                mouseButtonLeft = false;
            }else{
                mouseButtonLeftClick = false;
            }

            if(al_mouse_button_down(&mouseState, 2)){
                mouseButtonRight = true;
            }else if(mouseButtonRight){
                mouseButtonRightClick = true;
                mouseButtonRight = false;
            }else{
                mouseButtonRightClick = false;
            }
            //Update Mouse Variables -

            //Rest +
            if(!al_key_down(&keyState, lastKeyPress)){
                lastKeyPress = 0;
            }
            //Rest -

            if(events.timer.source == timer){
                newTime = al_get_time();
                frameTime = newTime - currentTime;
                if(frameTime > 0.25)
                    frameTime = 0.25;	  // note: max frame time to avoid spiral of death
                currentTime = newTime;

                accumulator += frameTime;

                while(accumulator >= dt){
                    engine.update(); //Call the gameState specfic update
                    t += dt;
                    accumulator -= dt;
                }

                engine.draw();

                al_draw_bitmap(cursorImage, mouseX-4, mouseY-4, 0);

                al_flip_display();
                al_clear_to_color(al_map_rgb(0, 0, 0));
            }
        }
        //Main Timer Event -
    }
	// cleanup the engine
	engine.cleanup();

}

bool isPassable(float x, float y, float width, float height){
    if(!insideMap(x, y, width, height)){
        return false;
    }else{
        int tX = floor(x/tileSize), tY = floor(y/tileSize), tWX = floor((x+width-1)/tileSize), tHY = floor((y+height-1)/tileSize);

        if(!tileIndex[mapArray[tX][tY]].isPassable || !tileIndex[mapArray[tWX][tY]].isPassable || !tileIndex[mapArray[tX][tHY]].isPassable || !tileIndex[mapArray[tWX][tHY]].isPassable){
            return false;
        }
    }
    return true;
}

bool checkCollision(float x, float y, float ex, float ey, float width, float height, float ewidth, float eheight){
    if(x + width - 1 < ex || x > ewidth + ex - 1 || y + height - 1 < ey || y > eheight + ey - 1){
        return false;
    }else{
        return true;
    }
}

bool insideMap(float x, float y, float width, float height){
    if(x < 0 || x + width-1 >= mapArrayWidth*tileSize || y < 0 || y + height-1 >= mapArrayHeight*tileSize){
        return false;
    }
    return true;
}

void addButtonToList(Button *newButton){
    for(int i = 0; i < MAX_BUTTONS; i++){
        if(buttonList[i] == NULL || !buttonList[i]->checkActive()){
            newButton->setEntityId(i);
            buttonList[i] = newButton;
            return;
        }
    }
}

void addMissileToList(MissileEntity *newMissile){
    for(int i = 0; i < MAX_MISSILES; i++){
        if(missileList[i] == NULL || !missileList[i]->checkActive()){
            newMissile->setEntityId(i);
            missileList[i] = newMissile;
            return;
        }
    }
}

void addLivingToList(LivingEntity *newLiving){
    for(int i = 0; i < MAX_LIVING; i++){
        if(livingList[i] == NULL || !livingList[i]->checkActive()){
            newLiving->setEntityId(i);
            livingList[i] = newLiving;
            return;
        }
    }
}

void addDebugToList(DebugClass *newDebug){
    for(int i = 0; i < MAX_DEBUG; i++){
        if(debugList[i] == NULL || !debugList[i]->checkActive()){
            newDebug->setEntityId(i);
            debugList[i] = newDebug;
            return;
        }
    }
}

void loadMapArray(){
    ifstream mapArrayFile;
    mapArrayFile.open("config/MapArray.txt");

    for(int y = 0; y < mapArrayHeight; y++){
        for(int x = 0; x < mapArrayWidth; x++){
            mapArrayFile >> mapArray[x][y];
        }
    }

    mapArrayFile.close();
}

void saveMapArray(){
    ofstream mapArrayFile;
    mapArrayFile.open("config/MapArray.txt");

    for(int y = 0; y < mapArrayHeight; y++){
        for(int x = 0; x <= mapArrayWidth; x++){
            if(x < mapArrayWidth){
                mapArrayFile << mapArray[x][y] << " ";
            }else if(x == mapArrayWidth){
                mapArrayFile << endl;
            }
        }
    }

    mapArrayFile.close();
}

void drawMap(){
    for(int x = 0; x < mapDisplayWidth/tileSize+1; x++){
        for(int y = 0; y < mapDisplayHeight/tileSize+1; y++){
            drawTile(x, y, mapArray[x][y]);
        }
    }
}

void drawTile(float x, float y, int tileId){
    switch(tileId){
        case 0:
            al_draw_filled_rectangle(x*tileSize, y*tileSize, (x+1)*tileSize, (y+1)*tileSize, al_map_rgb(150, 150, 150));
            break;

        case 1:
            al_draw_filled_rectangle(x*tileSize, y*tileSize, (x+1)*tileSize, (y+1)*tileSize, al_map_rgb(75, 75, 75));
            break;

        case 2:
            al_draw_bitmap(portalImage, x*tileSize, y*tileSize, NULL);
            break;
    }
}
